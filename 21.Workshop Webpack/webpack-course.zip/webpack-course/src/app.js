class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

const person = new Person('Peter', 19);
console.log('Name: ', person.name);
console.log('Age: ', person.age);
